# Regression

Homework 1

## Environment

* Python 3.7+

## Requirements

* matplotlib (for plot images)
* numpy (for built-in matrix operation)

## IDE

* No

## Description

Use linear regression to find nonlinear model